package com.staryy.droidbattle;
import java.util.Scanner;
import com.staryy.droidbattle.Interface.InterfaceOfGame;


public class Main {
    public static void main(String[] args){
        InterfaceOfGame.startGame();
    }
}